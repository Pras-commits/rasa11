from __future__ import absolute_import
from __future__ import division
from __future__ import unicode_literals
from __future__ import print_function

from rasa_core_sdk import Action
from rasa_core_sdk.events import SlotSet
from rasa_core.agent import Agent
from pymongo import MongoClient

#===================API KEYS=============================
goog_api_key = 'AIzaSyBxxrPmnsEdulz7tVLY6PR8rKtZeOMRNWo'
openweather_api_key = '1a2b5effca6c5153434850ab54b48d4e'
#========================================================

import json
import requests
import urllib.request
import datetime
import urllib3
from datetime import datetime

client = MongoClient('localhost', 27018) # OFFICE CONNECT WITH PORT
db = client.convai

res=[]
http=urllib3.PoolManager()
data_list=[]
upcoming_list=[]
sr_list=[]
dmp_list=[]

proxy_dict = {'http': 'http://192.168.115.21:80', 'https': 'https://192.168.115.21:80'}

class ActionWeather(Action):
	def name(self):
		return 'action_weather'
		
	def run(self, dispatcher, tracker, domain):
		weat_loc = tracker.get_slot('location');
		owm_url = 'https://api.openweathermap.org/data/2.5/weather?units=metric'
		if ( weat_loc == 'default'):
			cursor = db.cva_user_loc.find({"userid":"shreeramuniq139"}).sort("epochdatetime", -1).limit(1);
			rev_geo_url = 'https://maps.googleapis.com/maps/api/geocode/json?latlng='+ str(cursor[0]['lat']) + ',' + str(cursor[0]['lon']) + '&key=AIzaSyBxxrPmnsEdulz7tVLY6PR8rKtZeOMRNWo';
			rev_geo_req = requests.get(rev_geo_url,proxies = proxy_dict);
			rev_geo_response = rev_geo_req.json();
			rev_geo_comp_code = rev_geo_response['plus_code']['compound_code']
			weat_loc = (rev_geo_comp_code.split(",")[0]).split(" ",1)[1]
			
		owm_param = {'q':weat_loc,'appid':openweather_api_key}
		owm_request = requests.get(owm_url,params=owm_param,
		proxies = proxy_dict)
		owm_response = owm_request.json()
		response = "Temperature currently is " + str(owm_response['main']['temp']) + " degree celsius. You can expect " + str(owm_response['weather'][0]['description'])
		dispatcher.utter_message("^GETWET^~" + weat_loc + "~" + response)
		return [SlotSet('location',weat_loc), SlotSet('pickup_location',weat_loc)]



#=======================================================
#         4.0 -- SEARCH RESTAURANT
#=======================================================
class ActionGetRestaurant(Action):
	def name(self):
		return 'action_restaurant'
     
	def run(self, dispatcher, tracker, domain):
		res_loc = tracker.get_slot('location')
		res_cuisine = tracker.get_slot('cuisine')

		if ( res_loc == 'default' ):
			cursor = db.cva_user_loc.find({"userid":"shreeramuniq139"}).sort("epochdatetime", -1).limit(1);
			lat_long = str(cursor[0]['lat']) + ',' + str(cursor[0]['lon'])
			rev_geo_url = 'https://maps.googleapis.com/maps/api/geocode/json?latlng='+ lat_long + '&key=AIzaSyBxxrPmnsEdulz7tVLY6PR8rKtZeOMRNWo';
			rev_geo_req = requests.get(rev_geo_url);
			rev_geo_response = rev_geo_req.json();
			rev_geo_comp_code = rev_geo_response['plus_code']['compound_code']
			res_loc = (rev_geo_comp_code.split(",")[0]).split(" ",1)[1]
			
		elif ( res_loc != 'default' ):
			geocode_url = 'https://maps.googleapis.com/maps/api/geocode/json'
			geocode_params = {'address': res_loc, 'key':goog_api_key}
			geocode_req = requests.get(geocode_url, params=geocode_params)
			geocode_response = geocode_req.json()   
			geodata = dict()
			geocode_result = geocode_response['results'][0]
			geodata['lat'] = geocode_result['geometry']['location']['lat']
			geodata['lon'] = geocode_result['geometry']['location']['lng']
			lat_long = str('{lat}, {lon}'.format(**geodata))
			
		goog_place_param = {'type':'restaurant', 'key':goog_api_key, 'location':lat_long,'radius':1000}
		goog_place_url='https://maps.googleapis.com/maps/api/place/nearbysearch/json?'
		goog_request= requests.get(goog_place_url, params=goog_place_param)
		goog_response = goog_request.json()
		restlist=[]
		for i in goog_response['results'][:5]: 
			restlist.append(json.dumps({"rest_id":i['id'],"name":i['name'],"addr":i['vicinity']}))
		dispatcher.utter_message("^GETRES^~" + res_loc + "~" + str(restlist))            
		return[SlotSet('location',res_loc)]
#==========================================================================================================================================================


#===============================================================================================
#  	  1.0 -- CAPTURE USER ID
#===============================================================================================
class ActionCaptureUserID(Action):
	def name(self):
		return 'action_storeuseid'
		
	def run(self, dispatcher, tracker, domain):
		juser_id = tracker.get_slot('user_id')
		ucuser = juser_id.upper();
		user_id = ucuser.replace('LLLLLLLLLLLL0000000000000>','')
		return[SlotSet('user_id',user_id), SlotSet('SR_flag', 'firstimenothing'),SlotSet('location', 'default'), SlotSet('drop_location','default'), SlotSet('pickup_location','default')]
		