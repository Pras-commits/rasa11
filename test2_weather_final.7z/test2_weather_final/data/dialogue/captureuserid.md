## Generated Story 906866282817065628
* captureuserid{"user_id": "LLLLLLLLLLLL0000000000000>prabha0901"}
    - slot{"user_id": "LLLLLLLLLLLL0000000000000>prabha0901"}



## Generated Story 3219010834770449418
* captureuserid{"user_id": "LLLLLLLLLLLL0000000000000>prabha0901"}
    - slot{"user_id": "LLLLLLLLLLLL0000000000000>prabha0901"}
* getrestaurant
    - action_restaurant
* getweather{"location": "chennai"}
    - slot{"location": "chennai"}
    - action_weather
    - slot{"location": "chennai"}


## story 01
* captureuserid{"user_id": "LLLLLLLLLLLL0000000000000>shreeramuniq"}
    - slot{"user_id": "LLLLLLLLLLLL0000000000000>shreeramuniq"}
    - action_storeuseid
    - slot{"user_id": "shreeramuni"}
	
## story 02
* captureuserid{"user_id": "LLLLLLLLLLLL0000000000000>shreeramuniq"}
    - slot{"user_id": "LLLLLLLLLLLL0000000000000>shreeramuniq"}
    - action_storeuseid
    - slot{"user_id": "shreeramuni"}
	
## story 03
* captureuserid{"user_id": "LLLLLLLLLLLL0000000000000>shreeramuniq"}
    - slot{"user_id": "LLLLLLLLLLLL0000000000000>shreeramuniq"}
    - action_storeuseid
    - slot{"user_id": "shreeramuni"}
	
## story 04
* captureuserid{"user_id": "LLLLLLLLLLLL0000000000000>ARVINDBA"}
    - slot{"user_id": "LLLLLLLLLLLL0000000000000>ARVINDBA"}
    - action_storeuseid
    - slot{"user_id": "ARVINDBA"}



## Generated Story 5379012078355705236
* captureuserid{"user_id": "LLLLLLLLLLLL0000000000000>prabha0901"}
    - slot{"user_id": "LLLLLLLLLLLL0000000000000>prabha0901"}
* getweather{"location": "chennai"}
    - slot{"location": "chennai"}
    - action_weather
    - slot{"location": "chennai"}


## Generated Story 5379012078355705236
* captureuserid{"user_id": "LLLLLLLLLLLL0000000000000>prabha0901"}
    - slot{"user_id": "LLLLLLLLLLLL0000000000000>prabha0901"}
* getweather{"location": "chennai"}
    - slot{"location": "chennai"}
    - action_weather
    - slot{"location": "chennai"}

