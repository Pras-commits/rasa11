## story 03
* captureuserid{"ORG": "XOXOXOXOXOXOXOXXOXOXSHREERAMUNI", "user_id": "xoxoxoxoxoxoxoxxoxoxshreeramuni"}
    - slot{"user_id": "xoxoxoxoxoxoxoxxoxoxshreeramuni"}
    - action_storeuseid
    - slot{"user_id": "shreeramuni"}
* getupcomingexpense
	- action_upcomingexpense
	- slot{"user_id": "shreeramuni"}
	
## story 04
* captureuserid{"ORG": "XOXOXOXOXOXOXOXXOXOXSHREERAMUNI", "user_id": "xoxoxoxoxoxoxoxxoxoxshreeramuni"}
    - slot{"user_id": "xoxoxoxoxoxoxoxxoxoxshreeramuni"}
    - action_storeuseid
    - slot{"user_id": "shreeramuni"}
* getupcomingexpense
	- action_upcomingexpense
	- slot{"user_id": "shreeramuni"}
	
## story 05
* captureuserid{"ORG": "XOXOXOXOXOXOXOXXOXOXSHREERAMUNI", "user_id": "xoxoxoxoxoxoxoxxoxoxshreeramuni"}
    - slot{"user_id": "xoxoxoxoxoxoxoxxoxoxshreeramuni"}
    - action_storeuseid
    - slot{"user_id": "shreeramuni"}
	
## story 06
* captureuserid{"ORG": "XOXOXOXOXOXOXOXXOXOXSHREERAMUNI", "user_id": "xoxoxoxoxoxoxoxxoxoxshreeramuni"}
    - slot{"user_id": "xoxoxoxoxoxoxoxxoxoxshreeramuni"}
    - action_storeuseid
    - slot{"user_id": "shreeramuni"}
* getupcomingexpense
	- action_upcomingexpense
	- slot{"user_id": "shreeramuni"}

	
## story 09
* captureuserid{"ORG": "XOXOXOXOXOXOXOXXOXOXSHREERAMUNI", "user_id": "xoxoxoxoxoxoxoxxoxoxshreeramuni"}
    - slot{"user_id": "xoxoxoxoxoxoxoxxoxoxshreeramuni"}
    - action_storeuseid
    - slot{"user_id": "shreeramuni"}
* getupcomingexpense
	- action_upcomingexpense
	- slot{"user_id": "shreeramuni"}

## story 10
* captureuserid{"ORG": "XOXOXOXOXOXOXOXXOXOXSHREERAMUNI", "user_id": "xoxoxoxoxoxoxoxxoxoxshreeramuni"}
    - slot{"user_id": "xoxoxoxoxoxoxoxxoxoxshreeramuni"}
    - action_storeuseid
    - slot{"user_id": "shreeramuni"}
* getupcomingexpense
	- action_upcomingexpense
	- slot{"user_id": "shreeramuni"}
	
## Generated Story -5150718255482508944
* captureuserid{"ORG": "LLLLLLLLLLLL0000000000000>507288355", "user_id": "llllllllllll0000000000000>507288355"}
    - slot{"user_id": "llllllllllll0000000000000>507288355"}
    - action_storeuseid
    - slot{"user_id": "507288355"}
    - slot{"SR_flag": "firstimenothing"}
    - slot{"location": "default"}
    - slot{"drop_location": "default"}
    - slot{"pickup_location": "default"}
* getupcomingexpense{"acc_act_type": "upcoming expense"}
    - action_upcomingexpense
    - slot{"user_id": "507288355"}
* getupcomingexpense{"acc_act_type": "upcoming expense"}
    - action_upcomingexpense
    - slot{"user_id": "507288355"}
* geteodbal
    - action_accntbal
* getweather{"location": "chennai"}
    - slot{"location": "chennai"}
    - action_weather
    - slot{"location": "chennai"}
    - slot{"pickup_location": "chennai"}
* getupcomingexpense{"acc_act_type": "upcoming expense"}
    - action_upcomingexpense
    - slot{"user_id": "507288355"}
    - export

	
## Generated Story -2428359032680847908
* captureuserid{"user_id": "xoxoxoxoxoxoxoxxoxoxprabha0901"}
    - slot{"user_id": "xoxoxoxoxoxoxoxxoxoxprabha0901"}
    - action_storeuseid
    - slot{"user_id": "XOXOXOXOXOXOXOXXOXOXPRABHA0901"}
    - slot{"SR_flag": "firstimenothing"}
* getstatements{"DATE": "today", "txntype": "expenses", "date": "today"}
    - slot{"DATE": "today"}
    - slot{"date": "today"}
    - action_getstatement

## Generated Story -8716538185516918660
* captureuserid{"user_id": "xoxoxoxoxoxoxoxxoxoxprabha0901"}
    - slot{"user_id": "xoxoxoxoxoxoxoxxoxoxprabha0901"}
    - action_storeuseid
    - slot{"user_id": "XOXOXOXOXOXOXOXXOXOXPRABHA0901"}
    - slot{"SR_flag": "firstimenothing"}
* getstatements{"DATE": "yesterday", "txntype": "expenses", "date": "yesterday"}
    - slot{"DATE": "yesterday"}
    - slot{"date": "yesterday"}
    - action_getstatement
* getstatements{"DATE": "yesterday", "txntype": "transactions", "date": "yesterday"}
    - slot{"DATE": "yesterday"}
    - slot{"date": "yesterday"}
    - action_getstatement
* getstatements{"DATE": "last 2 weeks", "txntype": "expenses", "date": "last 2 weeks"}
    - slot{"DATE": "last 2 weeks"}
    - slot{"date": "last 2 weeks"}
    - action_getstatement
* getupcomingexpense{"acc_act_type": "upcoming expense"}
    - action_upcomingexpense
    - slot{"user_id": "XOXOXOXOXOXOXOXXOXOXPRABHA0901"}
* getupcomingexpense{"acc_act_type": "upcoming expense"}
    - action_upcomingexpense
    - slot{"user_id": "XOXOXOXOXOXOXOXXOXOXPRABHA0901"}
* getstatements{"txntype": "expenses"}
    - action_getstatement
* getstatements{"txntype": "expenses"}
    - action_getstatement
* getstatements{"DATE": "last week", "txntype": "expenses", "date": "last week"}
    - slot{"DATE": "last week"}
    - slot{"date": "last week"}
    - action_getstatement
* getstatements{"DATE": "last month", "txntype": "expenses", "date": "last month"}
    - slot{"DATE": "last month"}
    - slot{"date": "last month"}
    - action_getstatement
* getstatements{"DATE": "last year", "txntype": "expenses", "date": "last year"}
    - slot{"DATE": "last year"}
    - slot{"date": "last year"}
    - action_getstatement
* getupcomingexpense{"DATE": "last week", "acc_act_type": "upcoming expense", "date": "last week"}
    - slot{"DATE": "last week"}
    - slot{"date": "last week"}
    - action_upcomingexpense
    - slot{"user_id": "XOXOXOXOXOXOXOXXOXOXPRABHA0901"}
* getupcomingexpense{"DATE": "last month", "acc_act_type": "upcoming expense", "date": "last month"}
    - slot{"DATE": "last month"}
    - slot{"date": "last month"}



## Generated Story -5153052621144981893
* captureuserid{"user_id": "xoxoxoxoxoxoxoxxoxoxprabha0901"}
    - slot{"user_id": "xoxoxoxoxoxoxoxxoxoxprabha0901"}
    - action_storeuseid
    - slot{"user_id": "XOXOXOXOXOXOXOXXOXOXPRABHA0901"}
    - slot{"SR_flag": "firstimenothing"}
* getstatements{"txntype": "expenses"}
    - action_getstatement
* getupcomingexpense{"acc_act_type": "upcoming expense"}
    - action_upcomingexpense
    - slot{"user_id": "XOXOXOXOXOXOXOXXOXOXPRABHA0901"}
* getstatements{"DATE": "14th septmeber 2019", "txntype": "expenses", "date": "14th septmeber 2019"}
    - slot{"DATE": "14th septmeber 2019"}
    - slot{"date": "14th septmeber 2019"}
    - action_getstatement
* getupcomingexpense{"DATE": "next week", "acc_act_type": "upcoming expense"}
    - slot{"DATE": "next week"}
    - action_upcomingexpense
    - slot{"user_id": "XOXOXOXOXOXOXOXXOXOXPRABHA0901"}
* getstatements{"DATE": "last x days", "txntype": "expenses", "date": "last x days"}
    - slot{"DATE": "last x days"}
    - slot{"date": "last x days"}
    - action_getstatement
* getstatements{"DATE": "last 2 weeks", "txntype": "expenses", "date": "last 2 weeks"}
    - slot{"DATE": "last 2 weeks"}
    - slot{"date": "last 2 weeks"}
    - action_getstatement
* getupcomingexpense{"acc_act_type": "upcoming expense"}
    - action_upcomingexpense
    - slot{"user_id": "XOXOXOXOXOXOXOXXOXOXPRABHA0901"}


## Generated Story 6028562443308888984
* captureuserid{"user_id": "xoxoxoxoxoxoxoxxoxoxprabha0901"}
    - slot{"user_id": "xoxoxoxoxoxoxoxxoxoxprabha0901"}
    - action_storeuseid
    - slot{"user_id": "XOXOXOXOXOXOXOXXOXOXPRABHA0901"}
    - slot{"SR_flag": "firstimenothing"}
* getupcomingexpense{"acc_act_type": "upcmng expenses"}
    - action_upcomingexpense
    - slot{"user_id": "XOXOXOXOXOXOXOXXOXOXPRABHA0901"}
* getupcomingexpense{"acc_act_type": "upcoming expense"}
    - action_upcomingexpense
    - slot{"user_id": "XOXOXOXOXOXOXOXXOXOXPRABHA0901"}
* getupcomingexpense{"DATE": "this month", "txntype": "expenses", "date": "this month"}
    - slot{"DATE": "this month"}
    - slot{"date": "this month"}
    - action_getstatement