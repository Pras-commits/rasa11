## story 05
* captureuserid{"ORG": "XOXOXOXOXOXOXOXXOXOXSHREERAMUNI", "user_id": "xoxoxoxoxoxoxoxxoxoxshreeramuni"}
    - slot{"user_id": "xoxoxoxoxoxoxoxxoxoxshreeramuni"}
    - action_storeuseid
    - slot{"user_id": "shreeramuni"}
* getsrdelivery
	- action_srdeliverables
	- slot{"user_id": "shreeramuni"}

## story 07
* captureuserid{"ORG": "XOXOXOXOXOXOXOXXOXOXSHREERAMUNI", "user_id": "xoxoxoxoxoxoxoxxoxoxshreeramuni"}
    - slot{"user_id": "xoxoxoxoxoxoxoxxoxoxshreeramuni"}
    - action_storeuseid
    - slot{"user_id": "shreeramuni"}
* getsrdelivery
	- action_srdeliverables
	- slot{"user_id": "shreeramuni"}