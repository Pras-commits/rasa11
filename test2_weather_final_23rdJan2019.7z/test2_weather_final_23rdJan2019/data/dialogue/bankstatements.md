## story 01
* captureuserid{"ORG": "XOXOXOXOXOXOXOXXOXOXSHREERAMUNI", "user_id": "xoxoxoxoxoxoxoxxoxoxshreeramuni"}
    - slot{"user_id": "xoxoxoxoxoxoxoxxoxoxshreeramuni"}
    - action_storeuseid
    - slot{"user_id": "shreeramuni"}
	
## story 02
* captureuserid{"ORG": "XOXOXOXOXOXOXOXXOXOXSHREERAMUNI", "user_id": "xoxoxoxoxoxoxoxxoxoxshreeramuni"}
    - slot{"user_id": "xoxoxoxoxoxoxoxxoxoxshreeramuni"}
    - action_storeuseid
    - slot{"user_id": "shreeramuni"}
	
## story 03
* captureuserid{"ORG": "XOXOXOXOXOXOXOXXOXOXSHREERAMUNI", "user_id": "xoxoxoxoxoxoxoxxoxoxshreeramuni"}
    - slot{"user_id": "xoxoxoxoxoxoxoxxoxoxshreeramuni"}
    - action_storeuseid
    - slot{"user_id": "shreeramuni"}
	
## story 04
* captureuserid{"ORG": "XOXOXOXOXOXOXOXXOXOXSHREERAMUNIQ", "user_id": "xoxoxoxoxoxoxoxxoxoxshreeramuni"}
    - slot{"user_id": "xoxoxoxoxoxoxoxxoxoxshreeramuni"}
    - action_storeuseid
    - slot{"user_id": "shreeramuni"}
	
## story 04
* captureuserid{"ORG": "XOXOXOXOXOXOXOXXOXOXSHREERAMUNI", "user_id": "xoxoxoxoxoxoxoxxoxoxshreeramuni"}
    - slot{"user_id": "xoxoxoxoxoxoxoxxoxoxshreeramuni"}
    - action_storeuseid
    - slot{"user_id": "shreeramuni"}
* getstatements
	- action_getstatement
	
## story 05
* captureuserid{"ORG": "XOXOXOXOXOXOXOXXOXOXSHREERAMUNI", "user_id": "xoxoxoxoxoxoxoxxoxoxshreeramuni"}
    - slot{"user_id": "xoxoxoxoxoxoxoxxoxoxshreeramuni"}
    - action_storeuseid
    - slot{"user_id": "shreeramuni"}
* getstatements
	- action_getstatement
	
## story 06
* captureuserid{"ORG": "XOXOXOXOXOXOXOXXOXOXSHREERAMUNI", "user_id": "xoxoxoxoxoxoxoxxoxoxshreeramuni"}
    - slot{"user_id": "xoxoxoxoxoxoxoxxoxoxshreeramuni"}
    - action_storeuseid
    - slot{"user_id": "shreeramuni"}
* getstatements
	- action_getstatement
* getstatements
	- action_getstatement
* getstatements
	- action_getstatement
* getstatements
	- action_getstatement
	
## story 07
* captureuserid{"ORG": "XOXOXOXOXOXOXOXXOXOXSHREERAMUNI", "user_id": "xoxoxoxoxoxoxoxxoxoxshreeramuni"}
    - slot{"user_id": "xoxoxoxoxoxoxoxxoxoxshreeramuni"}
    - action_storeuseid
    - slot{"user_id": "shreeramuni"}
* getstatements
	- action_getstatement
* getstatements
	- action_getstatement
* getstatements
	- action_getstatement

## story 08
* captureuserid{"ORG": "XOXOXOXOXOXOXOXXOXOXSHREERAMUNI", "user_id": "xoxoxoxoxoxoxoxxoxoxshreeramuni"}
    - slot{"user_id": "xoxoxoxoxoxoxoxxoxoxshreeramuni"}
    - action_storeuseid
    - slot{"user_id": "shreeramuni"}
* getstatements
	- action_getstatement
* getstatements
	- action_getstatement

## story 09
* captureuserid{"ORG": "XOXOXOXOXOXOXOXXOXOXSHREERAMUNI", "user_id": "xoxoxoxoxoxoxoxxoxoxshreeramuni"}
    - slot{"user_id": "xoxoxoxoxoxoxoxxoxoxshreeramuni"}
    - action_storeuseid
    - slot{"user_id": "shreeramuni"}
* getstatements
	- action_getstatement
* getstatements
	- action_getstatement
* getstatements
	- action_getstatement

## story 10
* captureuserid{"ORG": "XOXOXOXOXOXOXOXXOXOXSHREERAMUNI", "user_id": "xoxoxoxoxoxoxoxxoxoxshreeramuni"}
    - slot{"user_id": "xoxoxoxoxoxoxoxxoxoxshreeramuni"}
    - action_storeuseid
    - slot{"user_id": "shreeramuni"}
* getstatements
	- action_getstatement
* getstatements
	- action_getstatement
* getstatements
	- action_getstatement
	
## story 11
* captureuserid{"ORG": "XOXOXOXOXOXOXOXXOXOXSHREERAMUNI", "user_id": "xoxoxoxoxoxoxoxxoxoxshreeramuni"}
    - slot{"user_id": "xoxoxoxoxoxoxoxxoxoxshreeramuni"}
    - action_storeuseid
    - slot{"user_id": "shreeramuni"}
* getstatements
	- action_getstatement
* getstatements
	- action_getstatement
* getstatements
	- action_getstatement