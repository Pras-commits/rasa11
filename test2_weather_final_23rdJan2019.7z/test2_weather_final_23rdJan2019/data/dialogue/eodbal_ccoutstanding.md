## Story 01
* captureuserid{"ORG": "XOXOXOXOXOXOXOXXOXOXSHREERAMUNI", "user_id": "xoxoxoxoxoxoxoxxoxoxshreeramuni"}
    - slot{"user_id": "xoxoxoxoxoxoxoxxoxoxshreeramuni"}
    - action_storeuseid
    - slot{"user_id": "shreeramuni"}
* geteodbal
	- action_accntbal
* getccoutstanding
	- action_ccoutstanding

## Story 02
* captureuserid{"ORG": "XOXOXOXOXOXOXOXXOXOXSHREERAMUNI", "user_id": "xoxoxoxoxoxoxoxxoxoxshreeramuni"}
    - slot{"user_id": "xoxoxoxoxoxoxoxxoxoxshreeramuni"}
    - action_storeuseid
    - slot{"user_id": "shreeramuni"}
* geteodbal
	- action_accntbal
* getccoutstanding
	- action_ccoutstanding
* geteodbal
	- action_accntbal
	
## Story 03
* captureuserid{"ORG": "XOXOXOXOXOXOXOXXOXOXSHREERAMUNI", "user_id": "xoxoxoxoxoxoxoxxoxoxshreeramuni"}
    - slot{"user_id": "xoxoxoxoxoxoxoxxoxoxshreeramuni"}
    - action_storeuseid
    - slot{"user_id": "shreeramuni"}
* getccoutstanding
	- action_ccoutstanding
* geteodbal
	- action_accntbal
	
## Story 04
* captureuserid{"ORG": "XOXOXOXOXOXOXOXXOXOXSHREERAMUNI", "user_id": "xoxoxoxoxoxoxoxxoxoxshreeramuni"}
    - slot{"user_id": "xoxoxoxoxoxoxoxxoxoxshreeramuni"}
    - action_storeuseid
    - slot{"user_id": "shreeramuni"}
* getccoutstanding
	- action_ccoutstanding

	
## Story 05
* captureuserid{"ORG": "XOXOXOXOXOXOXOXXOXOXSHREERAMUNI", "user_id": "xoxoxoxoxoxoxoxxoxoxshreeramuni"}
    - slot{"user_id": "xoxoxoxoxoxoxoxxoxoxshreeramuni"}
    - action_storeuseid
    - slot{"user_id": "shreeramuni"}
* geteodbal
	- action_accntbal
* getccoutstanding
	- action_ccoutstanding

	
## Story 06
* captureuserid{"ORG": "XOXOXOXOXOXOXOXXOXOXSHREERAMUNI", "user_id": "xoxoxoxoxoxoxoxxoxoxshreeramuni"}
    - slot{"user_id": "xoxoxoxoxoxoxoxxoxoxshreeramuni"}
    - action_storeuseid
    - slot{"user_id": "shreeramuni"}
* geteodbal
	- action_accntbal

## Story 07
* captureuserid{"ORG": "XOXOXOXOXOXOXOXXOXOXSHREERAMUNI", "user_id": "xoxoxoxoxoxoxoxxoxoxshreeramuni"}
    - slot{"user_id": "xoxoxoxoxoxoxoxxoxoxshreeramuni"}
    - action_storeuseid
    - slot{"user_id": "shreeramuni"}
* getccoutstanding
	- action_ccoutstanding