## story_01
* captureuserid{"user_id": "xoxoxoxoxoxoxoxxoxoxshreeramuniq139"}
    - slot{"user_id": "xoxoxoxoxoxoxoxxoxoxshreeramuniq139"}
    - action_storeuseid
    - slot{"user_id": "shreeramuniq139"}
* getcab{"pickup_location": "chennai", "drop_location": "mumbai"}
    - slot{"pickup_location": "chennai"}
    - slot{"drop_location": "mumbai"}
    - action_getcab
    - slot{"pickup_location": "chennai"}
    - slot{"drop_location": "mumbai"}
    - slot{"ifcabbooked": true}
    - slot{"user_id": "shreeramuniq139"}
    - slot{"bkd_pickup_location": "chennai"}
    - slot{"bkd_drop_location": "mumbai"}

	
## story_02
* captureuserid{"user_id": "xoxoxoxoxoxoxoxxoxoxshreeramuniq139"}
    - slot{"user_id": "xoxoxoxoxoxoxoxxoxoxshreeramuniq139"}
    - action_storeuseid
    - slot{"user_id": "shreeramuniq139"}
* getcab{"pickup_location": "chennai", "drop_location": "mumbai"}
    - slot{"pickup_location": "chennai"}
    - slot{"drop_location": "mumbai"}
    - action_getcab
    - slot{"pickup_location": "chennai"}
    - slot{"drop_location": "mumbai"}
    - slot{"ifcabbooked": true}
    - slot{"user_id": "shreeramuniq139"}
    - slot{"bkd_pickup_location": "chennai"}
    - slot{"bkd_drop_location": "mumbai"}

	
## story_03
* captureuserid{"user_id": "xoxoxoxoxoxoxoxxoxoxshreeramuniq139"}
    - slot{"user_id": "xoxoxoxoxoxoxoxxoxoxshreeramuniq139"}
    - action_storeuseid
    - slot{"user_id": "shreeramuniq139"}
* getcab{"pickup_location": "chennai", "drop_location": "mumbai"}
    - slot{"pickup_location": "chennai"}
    - slot{"drop_location": "mumbai"}
    - action_getcab
    - slot{"pickup_location": "chennai"}
    - slot{"drop_location": "mumbai"}
    - slot{"ifcabbooked": true}
    - slot{"user_id": "shreeramuniq139"}
    - slot{"bkd_pickup_location": "chennai"}
    - slot{"bkd_drop_location": "mumbai"}

	
## story_04
* captureuserid{"user_id": "xoxoxoxoxoxoxoxxoxoxshreeramuniq139"}
    - slot{"user_id": "xoxoxoxoxoxoxoxxoxoxshreeramuniq139"}
    - action_storeuseid
    - slot{"user_id": "shreeramuniq139"}
* getcab{"pickup_location": "chennai", "drop_location": "mumbai"}
    - slot{"pickup_location": "chennai"}
    - slot{"drop_location": "mumbai"}
    - action_getcab
    - slot{"pickup_location": "chennai"}
    - slot{"drop_location": "mumbai"}
    - slot{"ifcabbooked": true}
    - slot{"user_id": "shreeramuniq139"}
    - slot{"bkd_pickup_location": "chennai"}
    - slot{"bkd_drop_location": "mumbai"}
