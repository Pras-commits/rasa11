## Story 01
* captureuserid{"ORG": "XOXOXOXOXOXOXOXXOXOXSHREERAMUNI", "user_id": "xoxoxoxoxoxoxoxxoxoxshreeramuni"}
    - slot{"user_id": "xoxoxoxoxoxoxoxxoxoxshreeramuni"}
    - action_storeuseid
    - slot{"user_id": "shreeramuni"}
* geteodbal
	- action_accntbal


## Story 02
* captureuserid{"ORG": "XOXOXOXOXOXOXOXXOXOXSHREERAMUNI", "user_id": "xoxoxoxoxoxoxoxxoxoxshreeramuni"}
    - slot{"user_id": "xoxoxoxoxoxoxoxxoxoxshreeramuni"}
    - action_storeuseid
    - slot{"user_id": "shreeramuni"}
* geteodbal
	- action_accntbal

	
## Story 03
* captureuserid{"ORG": "XOXOXOXOXOXOXOXXOXOXSHREERAMUNI", "user_id": "xoxoxoxoxoxoxoxxoxoxshreeramuni"}
    - slot{"user_id": "xoxoxoxoxoxoxoxxoxoxshreeramuni"}
    - action_storeuseid
    - slot{"user_id": "shreeramuni"}
* geteodbal
	- action_accntbal
	
## Story 04
* captureuserid{"ORG": "XOXOXOXOXOXOXOXXOXOXSHREERAMUNI", "user_id": "xoxoxoxoxoxoxoxxoxoxshreeramuni"}
    - slot{"user_id": "xoxoxoxoxoxoxoxxoxoxshreeramuni"}
    - action_storeuseid
    - slot{"user_id": "shreeramuni"}


	
## Story 05
* captureuserid{"ORG": "XOXOXOXOXOXOXOXXOXOXSHREERAMUNI", "user_id": "xoxoxoxoxoxoxoxxoxoxshreeramuni"}
    - slot{"user_id": "xoxoxoxoxoxoxoxxoxoxshreeramuni"}
    - action_storeuseid
    - slot{"user_id": "shreeramuni"}
* geteodbal
	- action_accntbal


	
## Story 06
* captureuserid{"ORG": "XOXOXOXOXOXOXOXXOXOXSHREERAMUNI", "user_id": "xoxoxoxoxoxoxoxxoxoxshreeramuni"}
    - slot{"user_id": "xoxoxoxoxoxoxoxxoxoxshreeramuni"}
    - action_storeuseid
    - slot{"user_id": "shreeramuni"}
* geteodbal
	- action_accntbal

## Story 07
* captureuserid{"ORG": "XOXOXOXOXOXOXOXXOXOXSHREERAMUNI", "user_id": "xoxoxoxoxoxoxoxxoxoxshreeramuni"}
    - slot{"user_id": "xoxoxoxoxoxoxoxxoxoxshreeramuni"}
    - action_storeuseid
    - slot{"user_id": "shreeramuni"}
